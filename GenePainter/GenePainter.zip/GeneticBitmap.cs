﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Imaging;

namespace GenePainter
{
    class GeneticBitmap
    {
        Random RNG;
        BackgroundWorker worker;
        Bitmap targetBitmap;

        int populationSize = 100;
        int maxChampions = 5;
        int mutationRate = 5;
        int accuracy = 50;
        int genomeLength = 800;
        int plateauMax = 100;
        int maxGenerations = 1000;

        bool genomeDynamic = true;
        bool keepBest = true;
        bool restoreDinosaurs = false;
        bool ruinPlateaus = false;
        bool useLog = true;
        bool infinite = false;

        public int generation = 0;
        public Genome bestGenome;
        public int bestFitness;
        public Bitmap generatedBitmap;

        public Bitmap publicGeneratedBitmap;

        private List<Genome> population;
        private List<Genome> champions;

        private object lockObject;
        

        //Default constructor
        public GeneticBitmap()
        {
            RNG = new Random();
            worker = new BackgroundWorker();
            lockObject = new Object();

            population = new List<Genome>(populationSize);
            champions = new List<Genome>(maxChampions);

            
        }

        public void Start(Bitmap input)
        {
            targetBitmap = new Bitmap(input);
            publicGeneratedBitmap = new Bitmap(targetBitmap.Width, targetBitmap.Height);
            

            // Create a background worker thread that ReportsProgress &
            // SupportsCancellation
            // Hook up the appropriate events.
            worker.DoWork += new DoWorkEventHandler(worker_DoWork);
            worker.ProgressChanged += new ProgressChangedEventHandler(worker_ProgressChanged);
            worker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(worker_RunWorkerCompleted);
            worker.WorkerReportsProgress = true;
            worker.WorkerSupportsCancellation = true;

            worker.RunWorkerAsync();
        }

        //Threading methods
        //==================================================================================
        private void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            //Insert heavy stuff here.
            GeneticAlgorithm();
            
        }

        private void worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            // This function fires on the UI thread so it's safe to edit
            // the UI control directly, no funny business with Control.Invoke
            // Update the progressBar with the integer supplied to us from the
            // ReportProgress() function. 

            lock (this)
            {
                publicGeneratedBitmap = new Bitmap(generatedBitmap);
            }
        }

        private void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // The background process is complete. We need to inspect
            // our response to see if an error occurred, a cancel was
            // requested or if we completed successfully.  
            if (e.Cancelled)
            { }
            // Check to see if an error occurred in the background process.
            else if (e.Error != null)
            { }
            else
            { }
        }
        //==================================================================================

        private void GeneticAlgorithm()
        {
            //Create initial population. Done.
            
            for (int i = 0; i <= populationSize; i++)
            {
                population.Insert(i, new Genome(genomeLength));
            }

            for (int i = 0; i <= maxChampions; i++)
            {
                champions.Insert(i, new Genome(genomeLength));
            }


            while(generation <= maxGenerations)
            {
                // 1. Test Fitnesses
                for (int i = 0; i <= populationSize; i++)
                {
                    population[i].Fitness = FitnessFunction(population[i]);
                }

                // 2. Name Champions
                for (int i = 0; i <= populationSize; i++)
                {
                    FindChampions(population[i]);
                }

                // 3. Breed New Generation
                Breed();

                generation++;
            }
        }



        private void Breed()
        {
            int index = 0;

            while (index <= maxChampions)
            {
                population[index] = champions[index];
                index++;
            }

            while (index <= populationSize)
            {
                int a = RNG.Next(maxChampions);
                int b = RNG.Next(maxChampions);

                population[index] = new Genome(champions[a], champions[b]);
                population[index].Mutate(mutationRate);

                index++;
            }
        }

        private void FindChampions(Genome genome)
        {
            if (genome.Fitness > champions[maxChampions].Fitness)
            {
                for (int i = 0; i <= maxChampions; i++)
                {
                    if (genome.Fitness > champions[i].Fitness)
                    {
                        champions[i] = genome;
                        break;
                    }
                }
            }

        }

        private int FitnessFunction(Genome genome)
        {
            float fitness = 0;

            generatedBitmap = GenomeToBitmap(genome);

            int sampleSize = (int)((float)((int)targetBitmap.Width * (int)targetBitmap.Height) * ((float)accuracy/100.0f));

            for (int i = 0; i < sampleSize; i++)
            {
                int rx;
                int ry;

                
                rx = RNG.Next(0, (int)targetBitmap.Width);
                ry = RNG.Next(0, (int)targetBitmap.Height);
                

                //Generated Color Values
                byte tRed;
                byte tGreen;
                byte tBlue;
                //byte tAlpha;
                //Generated Color Values
                byte gRed;
                byte gGreen;
                byte gBlue;
                //byte gAlpha;

                //get the target color values
                Color tColor = targetBitmap.GetPixel(rx, ry);
                tRed = tColor.R;
                tBlue = tColor.B;
                tGreen = tColor.G;
                //get the generated color values
                Color gColor = new Color();
                lock (this)
                {
                    gColor = generatedBitmap.GetPixel(rx, ry);
                }
                gRed = gColor.R;
                gBlue = gColor.B;
                gGreen = gColor.G;

                //get the color differences
                double RedError = Math.Abs(tRed - gRed);
                double GreenError = Math.Abs(tGreen - gGreen);
                double BlueError = Math.Abs(tBlue - gBlue);

                //=======================================================
                //Actual fitness function
                //-------------------------------------------------------

                float RedGrade = 1.0f - ((float)RedError / (float)255);
                float GreenGrade = 1.0f - ((float)GreenError / (float)255);
                float BlueGrade = 1.0f - ((float)BlueError / (float)255);

                fitness += (float)(Math.Pow((double)(RedGrade + GreenGrade + BlueGrade), (double)3));

                //=======================================================
            }

            if (fitness > bestFitness) 
            { 
                bestFitness = (int)fitness;
                bestGenome = genome;
            }

            worker.ReportProgress((int)fitness, generatedBitmap);

            return (int)fitness;
        }

        private Bitmap GenomeToBitmap(Genome genome)
        {
            int index = 0;
            Bitmap output = new Bitmap(targetBitmap.Width, targetBitmap.Height);
            Graphics g = Graphics.FromImage(output);


            while (index <= genome.Size)
            {
                if ((genome.Size - index) >= 8)
                {

                    int ca = genome[index];
                    index++;
                    int cr = genome[index];
                    index++;
                    int cg = genome[index];
                    index++;
                    int cb = genome[index];
                    index++;
                    int sx = (int)(((float)genome[index] / 255.0f) * (float)targetBitmap.Width);
                    index++;
                    int sy = (int)(((float)genome[index] / 255.0f) * (float)targetBitmap.Height);
                    index++;
                    int sw = (int)(((float)genome[index] / 255.0f) * (float)targetBitmap.Width);
                    index++;
                    int sh = (int)(((float)genome[index] / 255.0f) * (float)targetBitmap.Height);
                    

                    
                    Color color = Color.FromArgb(ca, cr, cg, cb);
                    SolidBrush brush = new SolidBrush(color);
                    g.FillRectangle(brush, sx, sy, sw, sh);
                }

                index++;
            }

            return output;
        }
    }
}
